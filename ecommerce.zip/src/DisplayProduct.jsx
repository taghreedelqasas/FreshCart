import React, { useContext, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Cartcontext } from './context/CartContext'
import toast from 'react-hot-toast';
import Productdetail from './Productdetail';
 


  





export default function DisplayProduct({prod}) {





   
   const [isActive,setIsActive] = useState(false)
    let [wishListItems,setwishLisTitems] = useState([])
  
  
  

    
  const notify = () => toast.success('Product Added Successfully ', {
    style: {
      border: '1px solid  #046C4E ',
      color:'#046C4E',
      
    },
  }); 
let   {addtocart,setItemsNum,wishList,getwishItems} = useContext(Cartcontext)
let isExit = wishListItems.some(item=> item._id === prod._id);
console.log(isExit)

 async  function getcard(productId){
   
       let response =  await addtocart(productId)
           
        if(response.data.status === 'success'){
          console.log('added')
          console.log(response.data)
          setItemsNum(response.data.numOfCartItems)
          notify();
        
        }else{
       
          console.log('error');
          toast.error('This is an error!',{
            style:{
              color:'red',
              border: '1px solid  red',
            }
          });
        }
    
      
}
 
 async function getwish(){
     
   let response = await getwishItems()
   console.log(response.data.data)
   setwishLisTitems(response.data.data)
 }
 useEffect(()=>{
    getwish()
   
 },[])

    

async  function addToWish(productId){
   
  let response =  await wishList(productId)
 
   if(response.data.status === 'success'){
     console.log('added')
     console.log(response.data)
     setIsActive(true)
      toast.success('Product Added successfully to your  wishList',{
        style:{
          backgroundColor:'#4FA74F',
          color:'white'
        }
      }

      )
   
   }else{
  
     console.log('error');
     toast.error('This is an error!',{
       style:{
         color:'red',
         border: '1px solid  red',
       }
     });
   }

 
}

 


   console.log(prod)
    console.log(prod.imageCover)

    let {imageCover,title,price,category,ratingsAverage,priceAfterDiscount,_id} = prod
  return ( 


 
    
    <div   className='w-1/2  md:w-1/3  lg:w-1/6        p-2  product  hover:shadow-green-300      hover:shadow-lg  rounded-lg  hover:inset-shadow-sm '>
      <Link         to={`/productdetail/${_id}/${category.name}`}>
       <div  className='p-3  off '>
       <img   src={imageCover}   className='w-full'  alt='image'  />
       <h1   className='text-green-color font-bold text-sm'>{category.name}</h1>
       <p>{title}</p>
       <div className="rate flex justify-between">
       <div  >
       <span className={`${priceAfterDiscount?' line-through ':''} `} >{price} EGP</span>
       {priceAfterDiscount?<p  className=''>{priceAfterDiscount} EGP</p>:''}
       </div>
        <span><i className="fa-solid fa-star  text-yellow-300  text-sm  me-2  "></i>{ratingsAverage}</span>
       </div>
       </div>
       </Link>
       <span onClick={()=>addToWish(_id)}  className=' cursor-pointer'      ><i         className={`fa-solid fa-heart font-bold  text-2xl  ${isActive?"text-red-600":" "}        ${isExit==true?"text-red-600":" "} `}  ></i></span>

       <button type="button"  onClick={()=>getcard(_id)}    className="text-white  btn    w-full  bg-green-700 hover:bg-green-800 focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-2.5  dark:bg-green-600 dark:hover:bg-green-700 focus:outline-none dark:focus:ring-green-800">Add to Cart</button>
      
       </div>
  
  )
}
