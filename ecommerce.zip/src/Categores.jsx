import axios from 'axios'
import React, { useEffect } from 'react'
import { useState } from 'react'
import Displaycat from './Displaycat'
import Slider from 'react-slick'

export default function Categores() {
 
  var settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 7,
    slidesToScroll: 1,
    autoplay:true,
  }

    let  [allactegory,setcategory] = useState([])


   async function getcategory(){
    const {data} = await axios.get(`https://ecommerce.routemisr.com/api/v1/categories`)
 
    setcategory(data.data)
   }

     console.log(allactegory)
       useEffect(()=>{
        getcategory()
       },[])
  return (
    <div  className='container w-[90%]  pt-16 '>
      <Slider  {...settings}>
      {allactegory.map(cat=> <Displaycat  cat={cat} ></Displaycat>)}
      </Slider>
    </div>
  )
}
