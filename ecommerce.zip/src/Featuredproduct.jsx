import axios from 'axios'
import React, { useEffect, useState } from 'react'
import DisplayProduct from './DisplayProduct'
import Loading from './Loading'
import { Link } from 'react-router-dom'

export default function Featuredproduct() {
 
    const [productsArr,setproduct] = useState([])
  
   
   async function getFeatued(){
    let {data} =  await axios.get(`https://ecommerce.routemisr.com/api/v1/products`)
    
    setproduct(data.data)
    }
      
   console.log(productsArr)
    useEffect(()=>{
        getFeatued()
    },[])
 
    return (
    <div>

   
      <div className="container  w-[95%]  mt-10">
        <div  className='flex flex-wrap   '>
       {productsArr.length?(productsArr.map(prod=><DisplayProduct  prod={prod}  key={prod._id} ></DisplayProduct>)):<Loading></Loading>}
      
        </div>
      </div>
    
    
    </div>
  )
}
