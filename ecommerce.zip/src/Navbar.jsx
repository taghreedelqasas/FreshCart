import React, { useContext } from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import { CounterContext } from './context/Countercontext'
import { Cartcontext } from './context/CartContext';



  

export default function Navbar() {

   let {ItemsNum} = useContext(Cartcontext)
   let navigate = useNavigate();
   function logout(){
    localStorage.removeItem('usertoken');
    setuserlogin(null);
    navigate('/login')
   }
   
    
  let {userlogin,setuserlogin} = useContext(CounterContext)
  return (
   
<nav className="bg-light-color border-gray-200 dark:bg-gray-900     hover:shadow-green-300     fixed w-full top-0 left-0 z-[1000]  ">
  <div className="max-w-screen-xl  md:flex      items-center justify-between mx-auto px-10 py-3 ">
    <div  className=' flex  justify-between' >
        <NavLink     to={'/'} className="flex items-center space-x-3  ">
    <i className="fa-solid fa-cart-shopping  text-2xl  text-green-color"></i>
      <span className="self-center text-2xl font-semibold whitespace-nowrap dark:text-white">FreshCart</span>
    </NavLink>
    <button data-collapse-toggle="navbar-default" type="button" className="inline-flex items-center p-2 w-10 h-10 justify-center text-sm text-gray-500 rounded-lg md:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600" aria-controls="navbar-default" aria-expanded="false">
      <span className="sr-only">Open main menu</span>
      <svg className="w-5 h-5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 17 14">
        <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M1 1h15M1 7h15M1 13h15" />
      </svg>
    </button>
    </div>



    {/* <NavLink     to={'/'} className="flex items-center space-x-3 rtl:space-x-reverse">
    <i className="fa-solid fa-cart-shopping  text-2xl  text-green-color"></i>
      <span className="self-center text-2xl font-semibold whitespace-nowrap dark:text-white">FreshCart</span>
    </NavLink>
    <button data-collapse-toggle="navbar-default" type="button" className="inline-flex items-center p-2 w-10 h-10 justify-center text-sm text-gray-500 rounded-lg md:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600" aria-controls="navbar-default" aria-expanded="false">
      <span className="sr-only">Open main menu</span>
      <svg className="w-5 h-5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 17 14">
        <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M1 1h15M1 7h15M1 13h15" />
      </svg>
    </button> */}
    <div className="hidden  md:flex md:w-[85%]   justify-between  " id="navbar-default">

  {
    userlogin !==null?<>
      <ul className="font-medium flex flex-col p-4 md:p-0 mt-4 border border-gray-100 rounded-lg  md:flex-row md:space-x-8 rtl:space-x-reverse md:mt-0 md:border-0  dark:bg-gray-800 md:dark:bg-gray-900 dark:border-gray-700">
        <li>
          <NavLink to={'/'} className="block   py-2 px-3 text-gray-400 rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-gray-800 md:p-0 dark:text-white md:dark:hover:text-blue-500 dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent" aria-current="page">Home</NavLink>
        </li>
        <li>
          <NavLink  to={'/cart'} className="block py-2 px-3 text-gray-400 rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-gray-800 md:p-0 dark:text-white md:dark:hover:text-blue-500 dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent">Cart</NavLink >
        </li>
        <li>
          <NavLink  to={'/products'} className="block py-2 px-3     text-gray-400 rounded hover:bg-gray-800 md:hover:bg-transparent md:border-0 md:hover:text-gray-800 md:p-0 dark:text-white md:dark:hover:text-blue-500 dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent">Products</NavLink >
        </li>
        <li>
          <NavLink  to={'/wishlist'} className="block py-2 px-3     text-gray-400 rounded hover:bg-gray-800 md:hover:bg-transparent md:border-0 md:hover:text-gray-800 md:p-0 dark:text-white md:dark:hover:text-blue-500 dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent">WishList</NavLink >
        </li>
        <li>
          <NavLink  to={'/category'} className="block py-2 px-3 text-gray-400 rounded hover:bg-gray-800 md:hover:bg-transparent md:border-0 md:hover:text-gray-800 md:p-0 dark:text-white md:dark:hover:text-blue-500 dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent">Categories</NavLink >
        </li>
        <li>
          <NavLink  to={'/brand'} className="block py-2 px-3 text-gray-400 rounded hover:bg-gray-800 md:hover:bg-transparent md:border-0 md:hover:text-gray-800 md:p-0 dark:text-white md:dark:hover:text-blue-500 dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent">Brands</NavLink >
        </li>
        <li>
     
 </li>
      </ul>   
     
    
    </>:null
  }


  {/* <ul className="font-medium flex flex-col p-4 md:p-0 mt-4 border border-gray-100 rounded-lg  md:flex-row md:space-x-8 rtl:space-x-reverse md:mt-0 md:border-0  dark:bg-gray-800 md:dark:bg-gray-900 dark:border-gray-700">
        <li>
          <NavLink to={'/'} className="block   py-2 px-3 text-gray-400 rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-gray-800 md:p-0 dark:text-white md:dark:hover:text-blue-500 dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent" aria-current="page">Home</NavLink>
        </li>
        <li>
          <NavLink  to={'/cart'} className="block py-2 px-3 text-gray-400 rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-gray-800 md:p-0 dark:text-white md:dark:hover:text-blue-500 dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent">Cart</NavLink >
        </li>
        <li>
          <NavLink  to={'/products'} className="block py-2 px-3     text-gray-400 rounded hover:bg-gray-800 md:hover:bg-transparent md:border-0 md:hover:text-gray-800 md:p-0 dark:text-white md:dark:hover:text-blue-500 dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent">Products</NavLink >
        </li>
        <li>
          <NavLink  to={'/category'} className="block py-2 px-3 text-gray-400 rounded hover:bg-gray-800 md:hover:bg-transparent md:border-0 md:hover:text-gray-800 md:p-0 dark:text-white md:dark:hover:text-blue-500 dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent">Categories</NavLink >
        </li>
        <li>
          <NavLink  to={'/brand'} className="block py-2 px-3 text-gray-400 rounded hover:bg-gray-800 md:hover:bg-transparent md:border-0 md:hover:text-gray-800 md:p-0 dark:text-white md:dark:hover:text-blue-500 dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent">Brands</NavLink >
        </li>
      </ul>    */}


      {
        userlogin ==null? <>
          <ul className="font-medium flex flex-col p-4 md:p-0 mt-4 border border-gray-100 rounded-lg  md:flex-row md:space-x-8 rtl:space-x-reverse md:mt-0 md:border-0  dark:bg-gray-800 md:dark:bg-gray-900 dark:border-gray-700">
        <li>
          <NavLink to={'/register'} className="block   py-2 px-3 text-gray-400 rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-gray-800 md:p-0 dark:text-white md:dark:hover:text-blue-500 dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent" aria-current="page">Register</NavLink>
        </li>
        <li>
          <NavLink    to={'/login'}  className="block py-2 px-3 text-gray-400 rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-gray-800 md:p-0 dark:text-white md:dark:hover:text-blue-500 dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent">login</NavLink >
        </li>
    
      </ul>    
      

        </>:null
      }
     
      {/* // <ul className="font-medium flex flex-col p-4 md:p-0 mt-4 border border-gray-100 rounded-lg  md:flex-row md:space-x-8 rtl:space-x-reverse md:mt-0 md:border-0  dark:bg-gray-800 md:dark:bg-gray-900 dark:border-gray-700">
      //   <li>
      //     <NavLink to={'/register'} className="block   py-2 px-3 text-gray-400 rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-gray-800 md:p-0 dark:text-white md:dark:hover:text-blue-500 dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent" aria-current="page">Register</NavLink>
      //   </li>
      //   <li>
      //     <NavLink    to={'/login'}  className="block py-2 px-3 text-gray-400 rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-gray-800 md:p-0 dark:text-white md:dark:hover:text-blue-500 dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent">login</NavLink >
      //   </li>
    
      // </ul>     */}
      
     
     {
      userlogin !==null?<>
      
      <ul className="font-medium flex flex-col p-4 md:p-0 mt-4   border border-gray-800   md:flex-row md:space-x-4 rtl:space-x-reverse md:mt-0 md:border-0 dark:bg-gray-800 md:dark:bg-gray-900 dark:border-gray-700">
        <li   className='relative '>
        <NavLink   to={'/cart'}   className="block py-2 px-3 text-gray-900    hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-green-color md:p-0 dark:text-white md:dark:hover:text-green-500 dark:hover:bg-gray-400 dark:hover:text-white md:dark:hover:bg-transparent"><i className="fa-solid fa-cart-shopping  text-3xl"></i></NavLink>
        <span   className='absolute  flex justify-center  items-center  h-5 w-5     rounded-full     bg-green-color  top-[-2px]   right-0   text-white'>{ItemsNum}</span>
        </li>
      

        <li>
          <a  className="block py-2 px-3 text-gray-400 rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-gray-800 md:p-0 dark:text-gray-400 md:dark:hover:text-green-500 dark:hover:bg-gray-400 dark:hover:text-white md:dark:hover:bg-transparent"><span  className='cursor-pointer  '  onClick={logout}  >Sign Out</span></a>
        </li>
      </ul> 
      </>:null


     }



      {/* <ul className="font-medium flex flex-col p-4 md:p-0 mt-4 border border-gray-800 rounded-lg  md:flex-row md:space-x-4 rtl:space-x-reverse md:mt-0 md:border-0 dark:bg-gray-800 md:dark:bg-gray-900 dark:border-gray-700">
        <li>
        <a href="#" className="block py-2 px-3 text-gray-900 rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-green-color md:p-0 dark:text-white md:dark:hover:text-green-500 dark:hover:bg-gray-400 dark:hover:text-white md:dark:hover:bg-transparent"><i className="fa-brands fa-facebook"></i></a>
        </li>
        <li>
          <a href="#" className="block py-2 px-3 text-gray-900 rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-green-color md:p-0 dark:text-white md:dark:hover:text-green-500 dark:hover:bg-gray-400 dark:hover:text-white md:dark:hover:bg-transparent"><i className="fa-brands fa-instagram"></i></a>
        </li>
        <li>
          <a href="#" className="block py-2 px-3 text-gray-900 rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-green-color md:p-0 dark:text-white md:dark:hover:text-green-500 dark:hover:bg-gray-400 dark:hover:text-white md:dark:hover:bg-transparent"><i className="fa-brands fa-twitter"></i></a>
        </li>
        <li>
          <a href="#" className="block py-2 px-3 text-gray-900 rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-green-color md:p-0 dark:text-white md:dark:hover:text-green-500 dark:hover:bg-gray-400 dark:hover:text-white md:dark:hover:bg-transparent"><i className="fa-brands fa-linkedin"></i></a>
        </li>
        <li>
          <a href="#" className="block py-2 px-3 text-gray-900 rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-green-color md:p-0 dark:text-white md:dark:hover:text-green-500 dark:hover:bg-gray-400 dark:hover:text-white md:dark:hover:bg-transparent"><i className="fa-brands fa-tiktok"></i></a>
        </li>
        <li>
          <a href="#" className="block py-2 px-3 text-gray-900 rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-green-color md:p-0 dark:text-white md:dark:hover:text-green-500 dark:hover:bg-gray-400 dark:hover:text-white md:dark:hover:bg-transparent"><i className="fa-brands fa-youtube"></i></a>
        </li>
        <li>
          <a  className="block py-2 px-3 text-gray-400 rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-gray-800 md:p-0 dark:text-gray-400 md:dark:hover:text-green-500 dark:hover:bg-gray-400 dark:hover:text-white md:dark:hover:bg-transparent"><span  className='cursor-pointer  '  onClick={logout}  >Sign Out</span></a>
        </li>
      </ul>     */}
   
 
 


    </div>
  </div>
</nav>


  )
}


