import axios from 'axios';
import React, { useContext, useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import Slider from 'react-slick';
import { Cartcontext } from './context/CartContext';





export   default    function Productdetail() {
 

 
 let  {getcard} = useContext(Cartcontext)

   var settings = {
      dots: true,
      infinite: true,
      speed: 500,
      slidesToShow: 7,
      slidesToScroll: 1
    };
   
    let [productdetail,setproductdetail] = useState()
    let [relatedproducts,setrelatedproducts] = useState([])

    let {id,category} = useParams();
  async  function getProductDetail(id){
       
      let  {data} = await axios.get(`https://ecommerce.routemisr.com/api/v1/products/${id}`)
     
    console.log(data)
    console.log(data.data.price)
  
   setproductdetail(data.data)
    }

    async  function getcategory(category){
       
       let  {data} = await axios.get(`https://ecommerce.routemisr.com/api/v1/products`)
          
        let allproducts =data.data

         let relatedproducts =   allproducts.filter((prod)=>prod.category.name ==category)
         console.log(relatedproducts)
         setrelatedproducts(relatedproducts)
     }



     useEffect(()=>{

        getProductDetail(id)
        getcategory(category)

     },[id])

  return (

    <div>      
    <div className="container flex  items-center        w-[90%]">
       <div  className='w-1/4   mt-28'>
    <img   className='w-full'   src={productdetail?.imageCover} />
       </div>
      <div  className='w-2/4   mx-10  '>
      <h2   className='   text-xl  font-bold '>{productdetail?.title }</h2>
      <p   className='my-3'>{productdetail?.description}</p>
   
      <div   className="rate flex justify-between">
       
      <span className={`${productdetail?.priceAfterDiscount?'    line-through ':''}   *:  text-xl  font-bold`} >{productdetail?.price} EGP</span>
      {productdetail?.priceAfterDiscount?<p  className='text-xl  font-bold '>{productdetail?.priceAfterDiscount} EGP</p>:''}
      
       <span   className='text-xl  font-bold'><i className="fa-solid fa-star  text-yellow-300  text-sm  me-2  "></i>{productdetail?.ratingsAverage}</span>
  
      </div>
      <button   onClick={()=>{getcard(id)}}      type="button" className="text-white   w-full   my-3 bg-green-700 hover:bg-green-800 focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:bg-green-600 dark:hover:bg-green-700 focus:outline-none dark:focus:ring-green-800">Add to Cart</button>


    </div>
    </div>
    
       <Slider     className='my-8'     {...settings}>
        {relatedproducts.map((produ)=>  
       <div   className='w-1/6  p-2  '>
       <Link to={`/productdetail/${produ._id}/${produ.category.name}`}>
        <div  className='p-3'>
        <img   src={produ.imageCover}   className='w-full'  alt='image'  />
        <h1   className='text-green-color font-bold text-sm'>{produ.category.name}</h1>
        <p>{produ.title}</p>
        <div className="rate flex justify-between">
        <div  >
        <span className={`${produ.priceAfterDiscount?' line-through ':''} `} >{produ.price} EGP</span>
        {produ.priceAfterDiscount?<p  className=''>{produ.priceAfterDiscount} EGP</p>:''}
        </div>
         <span><i className="fa-solid fa-star  text-yellow-300  text-sm  me-2  "></i>{produ.ratingsAverage}</span>
        </div>
        </div>
        </Link>
     </div>
   )}

       </Slider>
    
    
    </div>

      
  
    


  )
}
