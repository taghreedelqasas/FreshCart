import { useFormik } from 'formik'
import React, { useContext } from 'react'
import { Cartcontext } from './context/CartContext'

export default function CheckOut() {
 
     let {checkout,cartId} = useContext(Cartcontext)
  
     async  function handleCheckout(cartId,url){
        console.log(cartId)
        console.log(formik.values)
        let response = await checkout(cartId,url,formik.values)
        console.log(response)
        if(response.data.status==='success'){

           window.location.href = response.data.session.url;
        }
      }

     let  formik = useFormik({
            initialValues:{
             
               details:'',
               phone:'',
               city:'',
               
       
            },
           onSubmit:()=>handleCheckout(cartId,'http://localhost:5173/')
          
         })
  return (
    <div  className='mx-auto  py-8 max-w-xl '>
    <h2  className='text-green-color  font-semibold   text-xl' >Check Out</h2>
 

    <form  onSubmit={formik.handleSubmit}    className="mt-8">


    <div className="relative z-0 w-full mb-5 group">
  <input type="text" name="details" onChange={formik.handleChange} onBlur={formik.handleBlur}       value={formik.values.details}     id="floating-details" className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-green-500 focus:outline-none focus:ring-0 focus:border-green-600 peer" placeholder=" " />
  <label htmlFor="floating-pass" className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 rtl:peer-focus:left-auto peer-focus:text-green-600 peer-focus:dark:text-green-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6">details</label>
</div>


<div className="relative z-0 w-full mb-5 group">
  <input type="password" name="phone" onChange={formik.handleChange} onBlur={formik.handleBlur}       value={formik.values.phone}     id="floating-phone" className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-green-500 focus:outline-none focus:ring-0 focus:border-green-600 peer" placeholder=" " />
  <label htmlFor="floating-phone" className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 rtl:peer-focus:left-auto peer-focus:text-green-600 peer-focus:dark:text-green-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6">Enter Your phone</label>
</div>

<div className="relative z-0 w-full mb-5 group">
  <input type="password" name="city" onChange={formik.handleChange} onBlur={formik.handleBlur}       value={formik.values.city}     id="floating-city" className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-green-500 focus:outline-none focus:ring-0 focus:border-green-600 peer" placeholder=" " />
  <label htmlFor="floating-pass" className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 rtl:peer-focus:left-auto peer-focus:text-green-600 peer-focus:dark:text-green-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6">Enter Your city</label>
</div>


<button type="submit" className="text-white bg-green-700 hover:bg-green-800 focus:ring-4 focus:outline-none focus:ring-green-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center dark:bg-green-600 dark:hover:bg-green-700 dark:focus:ring-green-800">Pay Now</button>

</form>
</div>
  )
}
