import React, { useContext, useState } from 'react'
import { useFormik } from 'formik'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'
import * as Yup from 'yup'
import { CounterContext } from './context/Countercontext'






export default function Register() {
   
    
   let {userlogin,setuserlogin} = useContext(CounterContext)
     let [loading ,setloading] = useState(false)
    
    let [registerror,setregisterror]=  useState('');
     let validationSchema= Yup.object().shape(
        {
            name:Yup.string().min(3,'minlenght 3 char').max(10,'maxlength 10 chars').required('name is required'),
            email:Yup.string().email('email is invalid').required('email is required'),
            phone:Yup.string().matches(/^01[0-2]\d{8}$/,'phone number is invalid').required('phone number is required'),
            password:Yup.string().matches(/^[A-Z][a-zA-Z0-9]{5,10}$/, 'Password must start with an uppercase and be 6-11 characters long') .required('Password is required'),
            rePassword:Yup.string().oneOf([Yup.ref('password')],'repassword not the same').required('repassword  is required'),


        }
     )



    let navigate = useNavigate();
    async function handleRegister(formvalues) {
      try {
          console.log(formvalues);
          
          let { data } = await axios.post('https://ecommerce.routemisr.com/api/v1/auth/signup', formvalues);
          
          console.log(data);
          if (data.message === 'success') {
              navigate('/');
              setloading(true)
              localStorage.setItem('usertoken',JSON.stringify(data.token))
              setuserlogin(data.token)

          } else {
              console.log(data.message);
              console.log('offfff');
             
          }
      } catch (error) {
          console.error('Error during registration:', error);
          console.log(error.response.data.message)
          setregisterror(error.response.data.message)
          
      }
  }
    
  console.log(registerror)
  


    //   function myvalidation(value){
    //     let errors ={};
    //     if(!value.name){
    //         errors.name = 'name is required'
    //     }else if(!/^[A-Z][a-z]{3,5}$/.test(value.name)){
    //         errors.name = 'name must start with uppercase '
    //   }

    //    if(!value.email){
    //     errors.email = 'email is required'
    //    }else if(!/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(value.email)){
    //       errors.email = 'email is Invalid'
    //    }

    //     return errors;

    //  }

     let  formik = useFormik({
        initialValues:{
           name:'',
           phone:'',
           email:'',
           password:'',
           rePassword:'',
   
        },
        validationSchema:validationSchema,
      onSubmit:handleRegister
     })

  return (
    <div  className='mx-auto  py-8 max-w-xl  pt-28 '>
        <h2  className='text-green-color  text-xl  font-semibold ' >Register Now</h2>
       {registerror?<div  className="my-5    p-4 mb-4 text-sm text-red-800 rounded-lg bg-red-50 dark:bg-gray-800 dark:text-red-400" role="alert">
  <span className="font-medium"></span>{registerror} {formik.errors.email}
</div>:null}

        <form  onSubmit={formik.handleSubmit}    className="mt-8">
  <div className="relative z-0 w-full mb-5 group">
      <input type="text" name="name" onChange={formik.handleChange} onBlur={formik.handleBlur}       value={formik.values.name}     id="floating-name" className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-green-500 focus:outline-none focus:ring-0 focus:border-green-600 peer" placeholder=" " />
      <label htmlFor="floating-name" className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 rtl:peer-focus:left-auto peer-focus:text-green-600 peer-focus:dark:text-green-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6">Enter Your Name</label>
  </div>
 {formik.errors.name && formik.touched.name?<div class="p-4 mb-4 text-sm text-red-800 rounded-lg bg-red-50 dark:bg-gray-800 dark:text-red-400" role="alert">
  <span class="font-medium"></span> {formik.errors.name}
</div>:null}
  
  <div className="relative z-0 w-full mb-5 group">
      <input type="email" name="email" onChange={formik.handleChange} onBlur={formik.handleBlur}       value={formik.values.email}     id="floating_email" className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-green-500 focus:outline-none focus:ring-0 focus:border-green-600 peer" placeholder=" " />
      <label htmlFor="floating_email" className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 rtl:peer-focus:left-auto peer-focus:text-green-600 peer-focus:dark:text-green-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6">Enter Your   Email address</label>
  </div>
 {formik.errors.email && formik.touched.email?<div  className="p-4 mb-4 text-sm text-red-800 rounded-lg bg-red-50 dark:bg-gray-800 dark:text-red-400" role="alert">
  <span className="font-medium"></span> {formik.errors.email}
</div>:null}
  <div className="relative z-0 w-full mb-5 group">
      <input type="text" name="phone" onChange={formik.handleChange} onBlur={formik.handleBlur}       value={formik.values.phone}     id="floating-phone" className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-green-500 focus:outline-none focus:ring-0 focus:border-green-600 peer" placeholder=" " />
      <label htmlFor="floating-phone" className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 rtl:peer-focus:left-auto peer-focus:text-green-600 peer-focus:dark:text-green-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6">Enter Your Phone</label>
  </div>
  {formik.errors.phone && formik.touched.phone?<div className="p-4 mb-4 text-sm text-red-800 rounded-lg bg-red-50 dark:bg-gray-800 dark:text-red-400" role="alert">
  <span className="font-medium"></span> {formik.errors.phone}
</div>:null}
  <div className="relative z-0 w-full mb-5 group">
      <input type="password" name="password" onChange={formik.handleChange} onBlur={formik.handleBlur}       value={formik.values.password}     id="floating-pass" className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-green-500 focus:outline-none focus:ring-0 focus:border-green-600 peer" placeholder=" " />
      <label htmlFor="floating-pass" className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 rtl:peer-focus:left-auto peer-focus:text-green-600 peer-focus:dark:text-green-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6">Enter Your Password</label>
  </div>
  {formik.errors.password && formik.touched.password?<div  className="p-4 mb-4 text-sm text-red-800 rounded-lg bg-red-50 dark:bg-gray-800 dark:text-red-400" role="alert">
  <span  className="font-medium"></span> {formik.errors.password}
</div>:null}
  <div className="relative z-0 w-full mb-5 group">
      <input type="password" name="rePassword" onChange={formik.handleChange} onBlur={formik.handleBlur}       value={formik.values.rePassword}     id="floating-repass" className="block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-green-500 focus:outline-none focus:ring-0 focus:border-green-600 peer" placeholder=" " />
      <label htmlFor="floating-repass" className="peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 rtl:peer-focus:left-auto peer-focus:text-green-600 peer-focus:dark:text-green-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6">Confirm your Password</label>
  </div>
  {formik.errors.rePassword&& formik.touched.rePassword?<div className="p-4 mb-4 text-sm text-red-800 rounded-lg bg-red-50 dark:bg-gray-800 dark:text-red-400" role="alert">
  <span className="font-medium"></span> {formik.errors.rePassword}
</div>:null}


  <button type="submit" className="text-white bg-green-700 hover:bg-green-800 focus:ring-4 focus:outline-none focus:ring-green-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center dark:bg-green-600 dark:hover:bg-green-700 dark:focus:ring-green-800">
   
    {loading?<i className="fa-solid fa-spinner fa-spin "></i>:'Submit'}
   </button>
  </form>
    </div>
  
  )
}
