import React, { useContext, useEffect, useState } from 'react'
import { Cartcontext } from './context/CartContext'
import Loading from './Loading';

export default function Wishlist() {


       let {getwishItems,deleteitemWish,getcard} = useContext(Cartcontext)
    let [wishitems,setwishitems] = useState([])
    
  async    function getWishList(){

      
       let response = await   getwishItems();
      //  console.log(response)
      //  console.log(response?.data?.data)
       setwishitems(response?.data?.data)
       

     }

   async    function removerWishItem(id){
     
         let response = await deleteitemWish(id)
            if(response.data.status ==='success'){
              console.log(response)
              setwishitems(response?.data?.data)
              console.log('removed')
              getWishList()
               
            }

            
      }
     

   
       useEffect(()=>{
        getWishList()
         
       },[])

      
  return (
    <div    className='text-center   container w-[90%]  pt-28'>
         

  {wishitems.length?( wishitems?.map(item=><>
         
         <div class="relative overflow-x-auto shadow-md   ">
<table className=" w-full container text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
<thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">

</thead>
<tbody>
 <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700 border-gray-200 hover:bg-gray-50 dark:hover:bg-gray-600">
   <td className="p-4">
     <img src={item.imageCover} className="w-16 md:w-32 max-w-full max-h-full" alt="Apple Watch" />
   </td>
   <td className="px-6 py-4 font-semibold text-gray-900 dark:text-white  text-center">
    {item.title}
   </td>
 
   <td className="px-6 py-4 font-semibold text-gray-900 dark:text-white">
     {item.price}$
   </td>
   <td className="px-6 py-4">
     <button   onClick={()=>{removerWishItem(item._id)}}    className="font-medium text-red-600 dark:text-red-500 "> <span ><i className="fa-solid fa-trash       text-red-700"></i></span>  Remove</button>
     
   </td>
   <td className="px-6 py-4    flex justify-end    ">
     
   <button type="button"  onClick={()=>{getcard(item._id)}}   className="text-white  btn      w-[200px] bg-green-700 hover:bg-green-800 focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-2.5  dark:bg-green-600 dark:hover:bg-green-700 focus:outline-none dark:focus:ring-green-800">Add to Cart</button>

     
   </td>
 </tr>
  
</tbody>
</table>

</div>





      
      </>)
    ):<Loading></Loading>}

{/* //          wishitems?.map(item=><>
         
//             <div class="relative overflow-x-auto shadow-md   ">
// <table className=" w-full container text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
//   <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">

//   </thead>
//   <tbody>
//     <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700 border-gray-200 hover:bg-gray-50 dark:hover:bg-gray-600">
//       <td className="p-4">
//         <img src={item.imageCover} className="w-16 md:w-32 max-w-full max-h-full" alt="Apple Watch" />
//       </td>
//       <td className="px-6 py-4 font-semibold text-gray-900 dark:text-white  text-center">
//        {item.title}
//       </td>
    
//       <td className="px-6 py-4 font-semibold text-gray-900 dark:text-white">
//         {item.price}$
//       </td>
//       <td className="px-6 py-4">
//         <button   onClick={()=>{removerWishItem(item._id)}}    className="font-medium text-red-600 dark:text-red-500 "> <span ><i className="fa-solid fa-trash       text-red-700"></i></span>  Remove</button>
        
//       </td>
//       <td className="px-6 py-4">
        
//       <button type="button"  onClick={()=>{getcard(item._id)}}   className="text-white  btn    w-full  bg-green-700 hover:bg-green-800 focus:ring-4 focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-2.5  dark:bg-green-600 dark:hover:bg-green-700 focus:outline-none dark:focus:ring-green-800">Add to Cart</button>

        
//       </td>
//     </tr>
     
//   </tbody>
// </table>

// </div>





         
//          </>)
        */}

  


     </div>
    )}
   
         
