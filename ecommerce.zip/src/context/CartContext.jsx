import axios from 'axios'
import React, { createContext, useEffect, useState } from 'react'
import toast from 'react-hot-toast';




 export  let Cartcontext = createContext()

 export default  function Cartcontextprovider(props){

   
     let [ItemsNum,setItemsNum] = useState(null)
     let[cartId,setcartId] = useState()

     const notify = () => toast.success('Product Added Successfully ', {
         style: {
           border: '1px solid  #046C4E ',
           color:'#046C4E',
           
         },
       });

  let headers = {
    token:localStorage.getItem('usertoken')
  }

  

   

    async  function addtocart(productId){

      return   axios.post(`https://ecommerce.routemisr.com/api/v1/cart`,{
        productId:productId
       },{
       headers:headers
       })
       .then((response)=> response)
       .catch((error)=>error)
      

     }

   async   function getcartitems(){

      return  axios.get('https://ecommerce.routemisr.com/api/v1/cart',{
       headers:headers

      })
       .then((response)=>response)
       .catch((err)=>err)
      
    
  }

   async  function deletecart(id){
      
       return   axios.delete(`https://ecommerce.routemisr.com/api/v1/cart/${id}`,
          {
            headers:headers
          }
         )
        .then((response)=>response)
        .catch((err)=>err)
          
      
   }
   async   function updateCart(id,count){
      
       return   axios.put(`https://ecommerce.routemisr.com/api/v1/cart/${id}`,{

      count:count
       },
          {
            
            headers:headers
          }
         )
        .then((response)=>response)
        .catch((err)=>err)
          
      
   }

        async  function getitems(){
       
             let response = await getcartitems()
              
              console.log(response.data.cartId)
              setcartId(response.data.cartId)
              console.log(response?.data?.data?.products)
             
              console.log(response.data.data.totalCartPrice)
              
              console.log(response.data.numOfCartItems)
              setItemsNum(response.data.numOfCartItems)
              console.log('hello')

          }
        
     useEffect(()=>{
      getitems()
       
     },[getcartitems])
 

   async  function getcard(productId){
   
    let response =  await addtocart(productId)
   
     if(response.data.status === 'success'){
       console.log('added')
       console.log(response.data)
       console.log('what')
       setItemsNum(response.data.numOfCartItems)
       notify();

     }else{
    
       console.log('error');
       toast.error('This is an error!',{
         style:{
           color:'red',
           border: '1px solid  red',
         }
       });
     }
 
   
}



  async  function clearCart(){
      
    return  axios.delete(`https://ecommerce.routemisr.com/api/v1/cart`,{
        headers:headers
      })
      .then((response)=>response)
      .catch((err)=>err)
      
  }
 

    async  function checkout(cartId,url,formValues){
       console.log(cartId,url,formValues)
      return axios.post(`https://ecommerce.routemisr.com/api/v1/orders/checkout-session/${cartId}?url=${url}`,{
        shippingAddress:formValues
      },{
        headers:headers
      })

     .then((response)=>response)
     .catch((err)=>err)
     

    }
     
 async    function wishList(productId){

      return   axios.post(`https://ecommerce.routemisr.com/api/v1/wishlist`,{
        productId:productId
       },{
       headers:headers
       })
       .then((response)=> response)
       .catch((error)=>error)
      

     }


  



   async   function getwishItems(){

      return  axios.get('https://ecommerce.routemisr.com/api/v1/wishlist',{
       headers:headers

      })
       .then((response)=>response)
       .catch((err)=>err)
      
    
  }

 async    function deleteitemWish(id){
      return   axios.delete(`https://ecommerce.routemisr.com/api/v1/wishlist/${id}`,
        {
          headers:headers
        }
       )
      .then((response)=>response)
      .catch((err)=>err)


    }
  
    async  function getbrands(){
        return axios.get('https://ecommerce.routemisr.com/api/v1/brands')
        .then((response)=>response)
        .catch((err)=>err)
      }

      

     return <Cartcontext.Provider  value={{addtocart,getcartitems,deletecart,getcard,clearCart,updateCart,ItemsNum,setItemsNum,checkout,cartId,wishList,getwishItems,deleteitemWish,getbrands}}     >
   
   {props.children}

     </Cartcontext.Provider>
      
   }



   
   

 
  

