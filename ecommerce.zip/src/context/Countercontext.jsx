import { useEffect, useState } from "react";
import { createContext } from "react";


 export  let CounterContext = createContext(0)
 export default function Coutercontextprovider(props){

      useEffect(()=>{
        if(localStorage.getItem('usertoken')!==null){
            setuserlogin(localStorage.getItem('usertoken'))
        }
         
      },[])


    
     let[counter,setcounter] = useState(0)
    let [userName,setuserName] = useState('ahmed')
    let [userlogin,setuserlogin] = useState(null)
    return<CounterContext.Provider  value={{userName,setcounter,counter,userlogin,setuserlogin}}   >
        {props.children}

    </CounterContext.Provider>
 }

