import React from 'react'
import Slider from 'react-slick';

export default function Displaycat({cat}) {

    console.log(cat)
  
  return (
 <div   className='my-20'>
  
      <img   className=' h-[200px]  object-cover'  src={cat.image}  />
       
  

 </div>
  )
}
