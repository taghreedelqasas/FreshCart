import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import Layout from './Layout'
import Home from './Home'
import Cart from './Cart'
import Products from './Products'
import Categores from './Categores'
import Brands from './Brands'
import Notfound from './Notfound'
import Register from './Register'
import Login from './Login'
import Coutercontextprovider from './context/Countercontext'
import Protected from './Protected'
import Productdetail from './Productdetail'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import Testquery from './Testquery'
import Cartcontextprovider from './context/CartContext'
import  { Toaster } from 'react-hot-toast';
import CheckOut from './CheckOut'
import Wishlist from './Wishlist'


let query = new QueryClient();

function App() {
 
  let routes = createBrowserRouter([
    {path:'/',element:<Layout></Layout>,children:[
      {index:true,element:<Protected><Home/></Protected>},
      {path:'/cart',element:<Protected><Cart/></Protected>},
      {path:'/register',element:<Register/>},
      {path:'/login',element:<Login></Login>},
      {path:'/testquery',element:<Testquery></Testquery>},
      {path:'/products',element:<Protected><Products/></Protected>},
      {path:'/wishlist',element:<Protected><Wishlist/></Protected>},
      {path:'/productdetail/:id/:category',element:<Protected><Productdetail/></Protected>},
      {path:'/category',element:<Protected><Categores/></Protected>},
      {path:'/checkout',element:<Protected><CheckOut/></Protected>},
      {path:'/brand',element:<Protected><Brands/></Protected>},
      {path:'*',element:<Notfound/>}
    ]}
  ])



  return (
    <>

   <Cartcontextprovider>
   <QueryClientProvider    client={query}>
    <Coutercontextprovider>
    <RouterProvider   router={routes} ></RouterProvider>
    <Toaster />
    </Coutercontextprovider>
    </QueryClientProvider>

   </Cartcontextprovider>

    
     
    </>
  )
}

export default App
