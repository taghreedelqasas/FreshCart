import React from 'react'
import img1 from './assets/images/grocery-banner-2.jpeg'
import img2 from './assets/images/slider-image-1.jpeg'
import img3 from './assets/images/slider-image-2.jpeg'
import img4 from './assets/images/slider-image-3.jpeg'
import img5 from './assets/images/blog-img-1.jpeg'
import Slider from "react-slick"

export default function Header() {
    var settings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay:true,
      

      };
  return (
    <div  className='flex  w-[90%]  container   pt-28       '>
     <div  className='w-2/3'>
     <Slider {...settings}>
      <img  className='h-[400px]  object-cover  rounded-lg'  src={img2}   alt=''/>
      <img className='h-[400px]  object-cover  rounded-lg'  src={img3}   alt=''/>
      <img  className='h-[400px] object-cover rounded-lg'  src={img4}   alt=''/>
    </Slider>
   
     </div>
     <div  className='w-1/3'>
      <img src={img1}   className='h-[200px]  object-cover rounded-lg' alt='' />
      <img src={img5}   className='h-[200px]  object-cover rounded-lg' alt='' />
     </div>
    </div>
  )
}
