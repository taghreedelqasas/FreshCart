import React from 'react'
import Featuredproduct from './Featuredproduct'

export default function Products() {
  return (
    <div  className='pt-28' >
      <Featuredproduct/>
    </div>
  )
}
