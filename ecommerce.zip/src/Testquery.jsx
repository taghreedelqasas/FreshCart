import { useQuery } from '@tanstack/react-query'
import axios from 'axios'
import React from 'react'
import Loading from './Loading'
import useProduct from './hooks/useProduct'


 
export default function Testquery() {

   
  // function getprod(){

  //   return axios.get(`https://ecommerce.routemisr.com/api/v1/products`)

  // }

  //    let {data,isLoading}=  useQuery({
     
  //        queryKey:['recentproduct'],
  //        queryFn:getprod

  //    }

  //    )


  let {isLoading ,data }= useProduct()

    
      console.log(data)
  return (


    <div>
      {isLoading===true?<Loading></Loading>:'test.........'}
    </div>
    
  )
}
``