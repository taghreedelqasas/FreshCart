import React, { useContext, useEffect, useState } from 'react'
import { CounterContext } from './context/Countercontext'
import { Cartcontext } from './context/CartContext'
import Loading from './Loading'

 

export default function Brands() {



  let [brands,setbrands] = useState([])
  let  {getbrands} = useContext(Cartcontext)
    async    function getAllBrands(){
     
       let {data} = await getbrands()
       console.log(data)
        setbrands(data.data)


    }

      useEffect(()=>{
        getAllBrands()

      },[])
  
  return (

    <div   className='flex    pt-28  flex-wrap  container w-[90%] '>
   {brands.length!==0?brands.map(brand=> <>
    
    <div    className='w-1/2  md:w-1/3  lg:w-1/4    hover:shadow-green-300     hover:shadow-lg  rounded-lg  hover:inset-shadow-sm   my-3     text-center'>
       <img src={brand.image}    />
       <h2>{brand.name}</h2>

    </div>
    



   
   </>):<Loading></Loading>}




    {/* // brands?.map(brand=> <>
    
    //  <div    className='w-1/4   my-3    hover:shadow-lg  hover:shadow-green-500/50   text-center'>
    //     <img src={brand.image}    />
    //     <h2>{brand.name}</h2>

    //  </div>
     



    
    // </>) */}
    
    


    </div>
  )
}
