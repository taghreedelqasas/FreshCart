import React from 'react'

export default function Loading() {
  return (
    <div  className='flex justify-center items-center   w-[100%]  h-screen'> 
        {/* <span class="loader  w-1.5"></span> */}
        <i class="fa-solid fa-spinner fa-spin fa-spin-reverse  text-[100px]  text-gray-700       font-bold   "></i>
    </div>
  )
}
