import React, { useContext, useEffect, useState } from 'react'
import { Cartcontext } from './context/CartContext'
import Cartdisplay from './Cartdisplay'
import { NavLink } from 'react-router-dom'
import Loading from './Loading'




export default function Cart() {

    
   let [cartitems,setcartitems] = useState([])
   let [totalPrice,setTotalPrice] = useState('')
   let {getcartitems,clearCart} = useContext(Cartcontext)
   let [numOfItems,setnumOfItems] = useState('')
   
    async  function getitems(){
   
         let response = await getcartitems()
          
          console.log(response?.data?.data?.products)
          setcartitems(response?.data?.data?.products)
          console.log(response.data.data.totalCartPrice)
          setTotalPrice(response.data.data.totalCartPrice)
          console.log(response.data.numOfCartItems)
          setnumOfItems(response.data.numOfCartItems)
      }
    
 useEffect(()=>{
  getitems()
   
 },[getcartitems])

      
    async  function clearAllCart(){
      
         let response = await clearCart()
         console.log(response)
         setcartitems(null)
         setTotalPrice(0)
         setnumOfItems(0)
      }
  

   


  return (
    <div className='text-center  pt-28  container w-[90%]  '>

  {cartitems.length?(cartitems?.map(item=><Cartdisplay  setTotalPrice={setTotalPrice}  setnumOfItems={setnumOfItems}   setcartitems={setcartitems}  item={item} ></Cartdisplay>)):<Loading></Loading>}



{/* // {cartitems?.map(item=><Cartdisplay  setTotalPrice={setTotalPrice}  setnumOfItems={setnumOfItems}   setcartitems={setcartitems}  item={item} ></Cartdisplay>)} */}


    
    {/* cartitems?.map(item=><Cartdisplay  setTotalPrice={setTotalPrice}  setnumOfItems={setnumOfItems}   setcartitems={setcartitems}  item={item} ></Cartdisplay>) */}
    <div className='text-center my-4   flex  justify-between  container  w-[80%]'>
<p  className='font-extrabold  text-2xl '><span className='text-blue-900 font-bold  text-lg'>Total Price </span>{totalPrice} $</p>
<p  className='font-extrabold  text-2xl '><span className='text-blue-900 font-bold  text-lg'>Num OF items </span>{numOfItems} </p>

</div>

     <button type="button" onClick={clearAllCart}   class="focus:outline-none text-white bg-green-700 hover:bg-green-800 focus:ring-4   my-4      focus:ring-green-300 font-medium rounded-lg text-xl    px-5 py-2.5  m-auto dark:bg-green-600 dark:hover:bg-green-700 dark:focus:ring-green-800">Clear Cart</button>
     <NavLink to={'/checkout'}   className="focus:outline-none text-white bg-blue-700 hover:bg-blue-800 focus:ring-4   my-4   mx-5    focus:ring-blue-300 font-medium rounded-lg text-xl    px-5 py-2.5  m-auto dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Check out</NavLink>
     </div>
  )
}