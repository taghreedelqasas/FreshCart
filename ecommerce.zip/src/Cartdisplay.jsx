import React, { useContext } from 'react'
import { Cartcontext } from './context/CartContext'
import { NavLink } from 'react-router-dom'
 
 


export default function Cartdisplay({item,setcartitems,setTotalPrice,setnumOfItems}) {

     let {count,price,product} = item
      let {deletecart,getcartitems,updateCart,setItemsNum} = useContext(Cartcontext)
     
       
     
      async function deleteitem(id) {
       
        
        console.log(id)

        let response = await   deletecart(id)
        console.log(response)
        getcartitems()
        setcartitems(response?.data?.data?.products)
        setTotalPrice(response.data.data.totalCartPrice)
        console.log(response.data.numOfCartItems)
        setnumOfItems(response.data.numOfCartItems)
        setItemsNum(response.data.numOfCartItems)
      }

   async   function updateItem(id,count){
      if(count<1)
        return
         console.log(count)
      
          let response =  await updateCart(id,count)
           console.log(response)
           getcartitems()
           setcartitems(response?.data?.data?.products)
           setTotalPrice(response.data.data.totalCartPrice)
        console.log(response.data.numOfCartItems)
        setnumOfItems(response.data.numOfCartItems)
     }
        
    


       
  return (
    <div  className=''>
      

<div class="relative overflow-x-auto shadow-md  ">
<table className="w-full      container text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
  <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
    {/* <tr>
      <th scope="col" className="px-16 py-3">
        <span className="sr-only">Image</span>
      </th>
      <th scope="col" className="px-6 py-3">
        Product
      </th>
      <th scope="col" className="px-6 py-3">
        Qty
      </th>
      <th scope="col" className="px-6 py-3">
        Price
      </th>
      <th scope="col" className="px-6 py-3">
        Action
      </th>
    </tr> */}
  </thead>
  <tbody  className=''>
    <tr className="bg-white border-b dark:bg-gray-800 dark:border-gray-700 border-gray-200 hover:bg-gray-50 dark:hover:bg-gray-600">
      <td className="p-4">
        <img src={product.imageCover} className="w-16 md:w-32 max-w-full max-h-full" alt="Apple Watch" />
      </td>
      <td className="px-6 py-4 font-semibold text-gray-900 dark:text-white  text-center">
       {product.title}
      </td>
      <td className="px-6 py-4">
        <div className="flex items-center">
          <button  onClick={()=>{updateItem(product._id,count-1) }}   className="inline-flex items-center justify-center p-1 me-3 text-sm font-medium h-6 w-6 text-gray-500 bg-white border border-gray-300 rounded-full focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-200 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700" type="button">
            <span className="sr-only">Quantity button</span>
            <svg className="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 18 2">
              <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M1 1h16" />
            </svg>
          </button>
          <div>
              <span  >{count}</span>
          </div>
          <button  onClick={()=>{updateItem(product._id,count+1) }}   className="inline-flex items-center justify-center h-6 w-6 p-1 ms-3 text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-full focus:outline-none hover:bg-gray-100 focus:ring-4 focus:ring-gray-200 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-600 dark:focus:ring-gray-700" type="button">
            <span className="sr-only">Quantity button</span>
            <svg className="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 18 18">
              <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 1v16M1 9h16" />
            </svg>
          </button>
        </div>
      </td>
      <td className="px-6 py-4 font-semibold text-gray-900 dark:text-white">
        {price}$
      </td>
      <td className="px-6 py-4">
        <button   onClick={()=>{ deleteitem(product._id)}}    className="font-medium text-red-600 dark:text-red-500 "> <span ><i className="fa-solid fa-trash  text-red-700"></i></span>  Remove</button>
        
      </td>
    </tr>
  </tbody>
</table>

</div>




    </div>


  )
}
