import React, { useContext } from 'react'
import Featuredproduct from './Featuredproduct'
import Header from './Header'
import Displaycat from './Displaycat'
import Categores from './Categores'
import { CounterContext } from './context/Countercontext'



export default function Home() {


  let x = useContext(CounterContext);
console.log(x)
  return (
    
    <div className=''>
    <Header></Header>
    <Categores></Categores>
    <Featuredproduct></Featuredproduct>
      
      </div>
  )
}

