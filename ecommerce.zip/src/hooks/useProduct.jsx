import { useQuery } from '@tanstack/react-query'
import axios from 'axios'
import React from 'react'

export default function useProduct() {

    

       
  function getprod(){

    return axios.get(`https://ecommerce.routemisr.com/api/v1/products`)

  }

     let responeInfo =  useQuery({
     
         queryKey:['recentproduct'],
         queryFn:getprod

     }

     )
return responeInfo 
   
  
}


